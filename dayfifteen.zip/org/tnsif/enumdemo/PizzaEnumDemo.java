package org.tnsif.enumdemo;

public class PizzaEnumDemo {
	
	enum Size{
		SMALL,MEDIUM,LARGE,EXTRALARGE
	};

}
